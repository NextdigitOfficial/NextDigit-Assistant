class AssetsManager {
  static String imagePath = "assets/images";
  static String userImage = "$imagePath/person1.png";
  static String botImage = "$imagePath/chat_logo.png";
  static String openaiLogo = "$imagePath/openai_logo.jpg";
}
