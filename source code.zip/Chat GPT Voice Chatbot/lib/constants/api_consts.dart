String BASE_URL = "https://api.openai.com/v1";
String baseUrl = "https://api.openai.com/v1/completions";
String apiUrl = "https://api.openai.com/v1/images/generations";

String API_KEY = "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";
